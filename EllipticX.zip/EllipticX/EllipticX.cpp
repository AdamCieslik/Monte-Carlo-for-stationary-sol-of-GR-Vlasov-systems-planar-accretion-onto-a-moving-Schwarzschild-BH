#include "WolframLibrary.h"
#include <math.h>

EXTERN_C DLLEXPORT mint WolframLibrary_getVersion( ) { return WolframLibraryVersion; }
EXTERN_C DLLEXPORT int WolframLibrary_initialize( WolframLibraryData libData) { return 0; }
EXTERN_C DLLEXPORT void WolframLibrary_uninitialize( WolframLibraryData libData) { return; }

EXTERN_C DLLEXPORT int EllipticX(WolframLibraryData libData, mint Argc, MArgument *Args, MArgument Res) {
	double xi,epsilon,lambda,wynik;
	double dz,t,temp1,temp2,incr,pi;
	xi      = MArgument_getReal(Args[0]);
	epsilon = MArgument_getReal(Args[1]);
	lambda  = MArgument_getReal(Args[2]);

	pi = acos(-1.0);

	dz = 1.0/16.0;
	wynik = 0.0;
	for(t = -4.0; t <= 4.0; t = t + dz)
	{
		temp1 = exp(0.5*pi*sinh(t));
		temp2 = temp1 + xi;
		incr = temp1*pi*lambda*cosh(t);
		incr = incr/(2.0*temp2*temp2);
		incr = incr/sqrt(epsilon*epsilon - (1.0 + lambda*lambda/(temp2*temp2))*(1.0 - 2.0/temp2));
		wynik = wynik + incr*dz;
	}

	MArgument_setReal(Res,wynik);
	return LIBRARY_NO_ERROR;
}
